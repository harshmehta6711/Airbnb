/**
 * Created by harshmehta6711 on 02-12-2016.
 */
var mq_client = require('../rpc/client');

function register(req,res)
{
    var email = req.param('email');
    var password = req.param('password');
    var first_name = req.param('fname');
    var last_name = req.param('lname');
    var response;

    var msg_payload = {"email":email,"password":password,"first_name":first_name,"last_name":last_name,"action":"Register"};
    mq_client.make_request('login_queue',msg_payload, function(err,results){
        console.log(results);
        if(err){
            response = {"statusCode":401,"data":null};
            res.send((response));
        }
        else
        {
            console.log("results "+ results.code);
            if(results.code == 200){
                response = {"statusCode":200,"data":results};
                req.session.login = {"first_name":first_name,"email":email};
                console.log(response);
                res.send((response));
            }
            else {
                response = {"statusCode":403,"data":null};
                res.send((response));
            }
        }
    });
}

exports.register = register;